import React from 'react';
import './Components/Header'
import './App.css';
import Header from './Components/Header';
import Card from './Components/Card';


class App extends React.Component {

  constructor() {
    super();
    this.state = {
      peoples:
        [{
          name: 'TES',
          age: 21

        }, {
          name: 'OK',
          age: 20
        }],

    }
  }



  render() {
    const items = [];
    for (var i = 0; i < this.state.peoples.length; i++) {
      items.push(<Card people={this.state.peoples[i]} />);
    }
    return (
      <div>
        <Header />
        <center style={{ padding: 30 }}>
          <button className='btn btn-primary' onClick={this.tambah} style={{ height: 50 }}>TAMBAH</button>

          <button className='btn btn-warning' onClick={this.kurang} style={{ height: 50 }}>KURANG</button>
        </center>
        <div className='container'>
          {items}<br />


        </div>
      </div>
    );
  }
  tambah = () => {
    this.state.peoples.push({ name: 'DUMMY', age: 20 });
    this.setState(this.state
    );
  }
  kurang = () => {
    this.state.peoples.pop();
    this.setState(this.state);
  }
}

export default App;
