import React from 'react';
import '../App.css';

class Card extends React.Component {
    constructor() {
        super();
        this.state = {
            number: 0
        }
    }

    render() {
        return (<div className='card' style={{ textAlign: 'center' }}>
            <p style={{ textAlign: 'left', marginLeft: 5 }}>{this.props.people.name}</p>
            <p style={{ textAlign: 'left', marginLeft: 5 }}>{this.props.people.age}</p>




            <p>{this.state.number}</p>
            <button onClick={this.tambah} style={{ width: 50, height: 50 }}>-</button>
            <button onClick={this.kurang} style={{ width: 50, height: 50 }}>+</button>
        </div>);
    }

    tambah = () => {
        this.setState(
            { number: this.state.number - 1 }
        );
    }
    kurang = () => {
        this.setState({
            number: this.state.number + 1
        });
    }
}
export default Card;